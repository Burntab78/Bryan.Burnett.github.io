### ATM program to securely log in via unique Id and PIN passcode from the accountInfo repository, make changes to account 
### Changes are deposit, withdraw of funds from the account. The ability to view the balance is present as well. 
### security measures in place via try/except methodology and secure login with unique user id and passcode.
### Check to see if VS was working. Had some issues after the update. print("hello!!!")

    ### import our repo file.
from progUserRepoRev import cardHolder

    ### Print options for user to choose.
def print_menu():
    print ("Please choose from one of the following options...")
    print ("1. Deposit Funds")
    print ("2. Withdraw Cash")
    print ("3. Check Balance")
    print ("4. Quit the System")


    ### Functions
    ### Deposit to verify user, and add funds to account as a float amount.
def deposit(cardHolder):
    try:
        deposit = float(input("How much would you like to deposit: "))
        cardHolder.set_balance(cardHolder.get_balance() + deposit)
        print("Thank you for your deposit. Your new balance is: ", str(cardHolder.get_balance()))
    ### Exception statement.
    except:
        print("Sorry, I don't understand. Please try again.")


    ### Withdraw to verify funds available, subtract funds from account.
def withdraw(cardHolder):
    try:
        withdraw = float(input("How much would you like to withdraw: "))
        ### verify funds available
        if(cardHolder.get_balance() < withdraw):
            print("Insufficient funds. Please enter another amount: ")
        else:
            cardHolder.set_balance(cardHolder.get_balance() - withdraw)
            print("Thank you for banking with us. Your new balance is: ", str(cardHolder.get_balance()))
    ### Exception statement to avoid endless loop/buffer overflow.
    except:
        print("Sorry, I don't understand. Please try again.")


    ### Check Balance simply checks available funds.
def check_balance(cardHolder):
    print("Your balance is: ", cardHolder.get_balance())


    ### Main Method
if __name__ == "__main__":
    ### initialize user at five empty sets to later set parameters (card#, pin, firstname, lastname, and balance).
    current_user = cardHolder("","","","","")

    ### Create repo of cardholders with initialized information.
list_of_cardHolders = []
list_of_cardHolders.append(cardHolder("00001", 1234, "Meg", "Griffin", 1423.34 ))
list_of_cardHolders.append(cardHolder("00002", 5678, "Lois", "Griffin", 13000.34))
list_of_cardHolders.append(cardHolder("00003", 9012, "Stewie", "Griffin", 4672936.65))
list_of_cardHolders.append(cardHolder("00004", 3456, "Peter", "Griffin", 999999999.99))
list_of_cardHolders.append(cardHolder("00005", 7890, "Brian", "Griffin", 75.57))

    ### Prompt user for debit card number
debitCardNum = ""
while True:
    try:
        debitCardNum = input("Please insert your debit card: ")
        ### Check against repo of users
        debitMatch = [holder for holder in list_of_cardHolders if holder.cardNum == debitCardNum]
        ### if there is a match, set as current user
        if (len(debitMatch) > 0):
            current_user = debitMatch[0]
        ### End with break, to stop endless looping
            break
        ### If not a match, print error statement, prompt for new input.
        else:
            print("Card number not recognized. Please try again.")
        ### Exception statement to avoid endless loop/buffer overflow.
    except:
        print("Card number not recognized. Please try again.")


    ### Prompt for PIN
while True:
    try:
        userPin = int(input("Please enter your PIN: ").strip())
    ### Validate PIN
        if (current_user.get_pin() == userPin):
            break
        else:
            print ("Incorrect PIN entered. Please try again.")
    ### Exception statement to avoid endless loop/buffer overflow.
    except:
        print("Sorry, PIN not recognized. Please try again.")


    ### Print Options- obtains user first name and inserts it into our welcome statement.
print ("Welcome to Our Little Bank, ", current_user.get_firstName(), "!")
option = 0
while True:
    print_menu()
    try:
        option = int(input())
    ### Exception statement to avoid endless loop/buffer overflow.
    except:
        print ("We can't seem to find that selection. Please try a number 1 through 4.")
        

    ### Menu choices- user to choose what function they wish to perform.
    if (option == 1):
        deposit(current_user)
    elif (option == 2):
        withdraw(current_user)
    elif (option == 3):
        check_balance(current_user)
    elif (option == 4):
        break
    ### If none of those choices apply, the choices are reloaded. 
    else:
        option = 0
print("Thank You, Have a nice day!")
print("ATM by Bryan Burnett for SNHU CS 499 Capstone")
print("Created June 2023")
