# Cardholders information (card number, pin, first and last names, balance.) Getter and setter methods for atm program to call upon, to alter carholders info.
# data repository for ATM program containing unique ID, PIN, first name, last name, and balance.

    ### Define values for each item in cardHolder
class cardHolder(): 
    def __init__(self, cardNum, pin, firstname, lastname, balance):
        self.cardNum = cardNum
        self.pin = pin
        self.firstname = firstname
        self.lastname = lastname
        self.balance = balance

    ### Getter methods get and return information
    def get_cardNum(self):
        return self.cardNum
    def get_pin(self):
        return self.pin    
    def get_firstName(self):
        return self.firstname   
    def get_lastName(self):
        return self.lastname    
    def get_balance(self):
        return self.balance

    ### Setter methods set and return information
    def set_cardNum(self, newVal):
        self.cardNum = newVal
    def set_pin(self, newVal):
        self.pin = newVal
    def set_firstName(self, newVal):
        self.firstName = newVal
    def set_lastName(self, newVal):
        self.lastName = newVal
    def set_balance(self, newVal):
        self.balance = newVal

    ### Print out what information is requested. 
    def print_out(self):
        print("Card #: ", self.cardNum)
        print("PIN #: ", self.pin)
        print("First Name #: ", self.firstname)
        print("Last Name #: ", self.lastname)
        print("Balance : ", self.balance)
