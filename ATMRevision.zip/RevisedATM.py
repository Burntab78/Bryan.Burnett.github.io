#ATM program.
from cardHolder import cardHolder

def print_menu():
    ## print options to user.
    print("Please choose from one of the following options: ")
    print("1. Deposit")
    print("2. Withdraw")
    print("3. Show Balance")
    print("4. Exit")

def deposit(cardHolder):
    try:
        deposit = float(input("Please enter the Deposit amount: "))
        cardHolder.set_balance(cardHolder.get_balance() + deposit)
        print("Thank you for your deposit.  Your new balance is: ", str(cardHolder.get_balance()), "\n")
    except:
        print("Invalid input.")

def withdraw(cardHolder):
    try:
        withdraw = float(input("Enter the amount you would like to withdraw: "))
        ### verify funds available
        if(cardHolder.get_balance() < withdraw):
            print("Insufficient funds. Please check your balance.\n")
        else: 
            cardHolder.set_balance(cardHolder.get_balance() - withdraw)
            print("you're all set! Your withrawal is complete.\n")
    except:
        print("Invalid input.")

def check_balance(cardHolder):
    print("Your current balance is: ", cardHolder.get_balance(), "\n")


    ###Main method

if __name__ == "__main__":
    current_user = cardHolder("","","","","")

    ### Create a repo of cardHolders. 
    list_of_cardHolders = []
    list_of_cardHolders.append(cardHolder("00006", 1234, "John", "Stamos", 1500000.23))
    list_of_cardHolders.append(cardHolder("00005", 9806, "Joe", "Responsible", 45674.28))
    list_of_cardHolders.append(cardHolder("00004", 5963, "Pam", "Andersen", 452872.87))
    list_of_cardHolders.append(cardHolder("00003", 7428, "Willy", "Wonka", 78.01))
    list_of_cardHolders.append(cardHolder("00002", 1111, "Peter", "Griffin", 0.12))
    list_of_cardHolders.append(cardHolder("00001", 1313, "Herman", "Munster", 999999999.99))

### Prompt user for debit card number
debitCardNum = ""
while True:
    try:
        debitCardNum = input("Please insert your debit card: ")
        ### Check against repo
        debitMatch = [holder for holder in list_of_cardHolders if holder.cardNum == debitCardNum]
        if(len(debitMatch) > 0):
            current_user = debitMatch[0]
            break
        else:
            print("Card number not recognized. Please try again.")
    except:
        print("Card number not recognized. Please try again.")

### Prompt for PIN
while True:
    try:
        userPin = int(input("Please enter your PIN: ").strip())
        if(current_user.get_pin() == userPin):
            break
        else:
            print("Invalid PIN. Please try again.")
    except:
        print("Invalid PIN. Please try again.")

### Print options
print("Welcome ", current_user.get_firstName(), " :)")
option = 0

while True:
    print_menu()
    try:
        option = int(input())
    except:
        print("Invalid input. Please try again.")

    if(option == 1):
        deposit(current_user)
    elif(option == 2):
        withdraw(current_user)
    elif(option == 3):
        check_balance(current_user)
    elif(option == 4):
        break
    else:
        option = 0

print("Thank you! Have a nice day!")
